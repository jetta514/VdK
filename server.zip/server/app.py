import base64
from concurrent.futures import ThreadPoolExecutor
import io
import json
import math
import os
import re
import shutil
import signal
import zipfile
from datetime import datetime
from flask import Flask, jsonify, render_template, request
from PIL import Image, ImageDraw, ImageOps

app = Flask(__name__)

# Инициализируем пул фоновых задач (1 рабочий поток)
executor = ThreadPoolExecutor(max_workers=1)

# ==========================================
# 1. ПУТИ И КОНФИГУРАЦИЯ
# ==========================================
RAZMETKA_DIR = "/sdcard/.VdK/Разметка"
ZAGRUZKA_DIR = "/sdcard/.VdK/Загрузка"
PHOTO_DEST_DIR = "/sdcard/Фото"
BACKUP_DIR = "/sdcard/.backup_task"
GPS_LOG_FILE = "/sdcard/.VdK/gps_log.txt"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
STATE_FILE = os.path.join(BASE_DIR, "app_state.json")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

# COMMENT_SUFFIX = "Все\nБудет\nХорошо"
COMMENT_SUFFIX = "════════════════\n🚗 Ищем перевозчиков. ЗП от 𝟓 𝐦𝐢𝐥𝐥𝐢𝐨𝐧𝐨𝐯/𝐦𝐞𝐬 🚗\n💸 Минимальный залог от 400к 💸\n⚡ АКЦИЯ 7+1 2025! Дарим 3000р!⚡\n🔔 Подробности на форуме - /shop/forum/d6879803-ad32-4da1-909c-b4333dc03d62/\n(Спасибо за любые предложения и комментарии)"

def ensure_dirs():
  for path in (
      RAZMETKA_DIR,
      ZAGRUZKA_DIR,
      PHOTO_DEST_DIR,
      BACKUP_DIR,
      TEMPLATES_DIR,
      os.path.dirname(GPS_LOG_FILE),
  ):
    try:
      os.makedirs(path, exist_ok=True)
    except OSError:
      pass


ensure_dirs()


def create_default_templates():
  menu_html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Главное Меню</title>
    <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
<div data-role="page" id="menu">
    <div data-role="header">
        <h1>Главное Меню</h1>
    </div>
    <div role="main" class="ui-content">
        <a href="/process" data-role="button">Перейти к разметке</a>
        <a href="/zagruzka" data-role="button">Перейти к загрузке</a>
    </div>
</div>
</body>
</html>
"""

  process_html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Разметка</title>
    <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
<div data-role="page" id="process-page">
    <div data-role="header">
        <a href="/" data-icon="home" data-ajax="false">Меню</a>
        <h1>Разметка: {{ folder_name if folder_name else 'Пусто' }}</h1>
    </div>
    <div role="main" class="ui-content">
        {% if empty %}
            <h3>Нет папок для разметки</h3>
        {% else %}
            <p>Папка: {{ folder_name }} ({{ current_idx + 1 }} из {{ total_folders }})</p>
            <div id="commentCoords">{{ comment_coords }}</div>
            <textarea id="commentInput">{{ comment_middle }}</textarea>
            <div id="commentSuffix" style="white-space: pre-wrap;">{{ comment_suffix }}</div>

            <button onclick="saveFolderData()" data-theme="b">Сохранить и далее</button>
            <button onclick="skipFolder()">Пропустить</button>
            <a href="#deleteConfirmPopup" data-rel="popup" data-position-to="window" data-transition="pop" data-role="button" data-theme="a">Удалить папку</a>
        {% endif %}
    </div>

    <div data-role="popup" id="deleteConfirmPopup" data-overlay-theme="a" data-theme="a" style="max-width:400px;" class="ui-corner-all">
        <div data-role="header" class="ui-corner-top">
            <h1>Подтверждение</h1>
        </div>
        <div role="main" class="ui-content ui-corner-bottom ui-body-a">
            <h3 class="ui-title">Вы действительно хотите удалить эту папку?</h3>
            <p>Это действие нельзя будет отменить.</p>
            <div style="text-align: right; margin-top: 15px;">
                <a href="#" data-rel="back" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-b" data-transition="flow">Отмена</a>
                <a href="#" onclick="confirmDeleteFolder()" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-delete" data-theme="delete">Удалить</a>
            </div>
        </div>
    </div>
</div>

<script>
    function saveFolderData() {
        const payload = {
            coords: $('#commentCoords').text(),
            comment: $('#commentInput').val() || '',
            suffix: $('#commentSuffix').text(),
            photo1_data: null,
            photo2_data: null
        };
        $.ajax({
            url: '/save_folder', method: 'POST', contentType: 'application/json',
            data: JSON.stringify(payload),
            success: function() { window.location.href = '/process'; },
            error: function() { alert('Ошибка сохранения!'); }
        });
    }

    function skipFolder() {
        $.post('/skip_folder', function() { window.location.href = '/process'; });
    }

    function confirmDeleteFolder() {
        $('#deleteConfirmPopup').popup('close');
        $.ajax({
            url: '/delete_folder',
            type: 'POST',
            success: function() { window.location.href = '/process'; },
            error: function() { alert('Ошибка при удалении'); }
        });
    }
</script>
</body>
</html>
"""

  zagruzka_html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Загрузка</title>
    <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
<div data-role="page" id="zagruzka-page">
    <div data-role="header">
        <a href="/" data-icon="home" data-ajax="false">Меню</a>
        <h1>Загрузка</h1>
    </div>
    <div role="main" class="ui-content">
        {% if empty %}
            <h3>Нет папок в загрузке</h3>
        {% else %}
            <p>Папка: {{ folder_name }}</p>
            <p>{{ comment_text }}</p>
            <button onclick="doAction('select')">Выбрать (Сохранить в Фото)</button>
            <button onclick="doAction('next')">Следующая</button>
            <button onclick="doAction('delete')">Удалить</button>
        {% endif %}
    </div>
</div>
<script>
    function doAction(actionName) {
        $.ajax({
            url: '/api/zagruzka/action',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ action: actionName }),
            success: function() { location.reload(); }
        });
    }
</script>
</body>
</html>
"""

  for filename, content in [
      ("menu.html", menu_html),
      ("process.html", process_html),
      ("zagruzka.html", zagruzka_html),
  ]:
    path = os.path.join(TEMPLATES_DIR, filename)
    if not os.path.exists(path):
      with open(path, "w", encoding="utf-8") as f:
        f.write(content)


create_default_templates()

app.config["TEMPLATES_AUTO_RELOAD"] = True


def load_state():
  default = {"current_folder_idx": 0, "zagruzka_folder_idx": 0}
  if not os.path.exists(STATE_FILE):
    return default
  try:
    with open(STATE_FILE, "r", encoding="utf-8") as f:
      data = json.load(f)
    default["current_folder_idx"] = int(data.get("current_folder_idx", 0))
    default["zagruzka_folder_idx"] = int(data.get("zagruzka_folder_idx", 0))
  except Exception:
    pass
  return default


def save_state():
  try:
    with open(STATE_FILE, "w", encoding="utf-8") as f:
      json.dump(
          {
              "current_folder_idx": state.get("current_folder_idx", 0),
              "zagruzka_folder_idx": state.get("zagruzka_folder_idx", 0),
          },
          f,
      )
  except Exception:
    pass


state = load_state()


# ==========================================
# 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ И ФОНОВАЯ ЛОГИКА
# ==========================================


def get_target_folders(target_dir=RAZMETKA_DIR):
  if not os.path.exists(target_dir):
    return []
  try:
    return sorted([
        f
        for f in os.listdir(target_dir)
        if os.path.isdir(os.path.join(target_dir, f))
    ])
  except OSError:
    return []


def clean_base64(b64_string):
  if not b64_string:
    return ""
  b64_string = re.sub(r"[\r\n\s]+", "", b64_string)
  if "," in b64_string:
    b64_string = b64_string.split(",", 1)[1]
  return b64_string


def read_file_content(folder_path, filename):
  file_path = os.path.join(folder_path, filename)
  if os.path.exists(file_path):
    try:
      with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read().strip()
    except OSError:
      pass
  return ""


def write_file_content(folder_path, filename, content):
  with open(os.path.join(folder_path, filename), "w", encoding="utf-8") as f:
    f.write(content)


def decode_comment(raw):
  if not raw:
    return ""
  try:
    return base64.b64decode(raw).decode("utf-8")
  except Exception:
    return raw


def encode_comment(text):
  return base64.b64encode(text.encode("utf-8")).decode("utf-8")


def split_comment(text):
  text = (text or "").replace("\r\n", "\n").replace("\r", "\n").strip()
  suffix = COMMENT_SUFFIX.strip()
  
  if text.endswith(suffix):
    text = text[:-len(suffix)].strip()
  elif text.endswith("\n" + suffix):
    text = text[:-len(suffix) - 1].strip()

  lines = text.split("\n") if text else []
  coord_lines = []
  i = 0
  while i < len(lines):
    s = lines[i].strip()
    if re.search(
        r"(?i)\b(lat|lon|latitude|longitude|координат|gps)\b", s
    ) or re.search(r"-?\d+[.,]\d+", s):
      coord_lines.append(s)
      i += 1
    else:
      break
  return "\n".join(coord_lines).strip(), "\n".join(lines[i:]).strip(), suffix


def draw_elements(img_bytes, arrow_start, arrow_end, canvas_size):
  with Image.open(io.BytesIO(img_bytes)) as image:
    image = ImageOps.exif_transpose(image).convert("RGB")

    draw = ImageDraw.Draw(image)
    orig_w, orig_h = image.size

    scale_x = orig_w / max(1, canvas_size["w"])
    scale_y = orig_h / max(1, canvas_size["h"])

    ax1, ay1 = int(arrow_start["x"] * scale_x), int(arrow_start["y"] * scale_y)
    ax2, ay2 = int(arrow_end["x"] * scale_x), int(arrow_end["y"] * scale_y)

    base_dim = min(orig_w, orig_h)
    line_width = max(4, int(base_dim // 100))
    arrow_size = max(20, int(base_dim // 20))

    draw.line([ax1, ay1, ax2, ay2], fill="red", width=line_width)
    angle = math.atan2(ay2 - ay1, ax2 - ax1)
    x_a1 = ax2 - arrow_size * math.cos(angle - math.pi / 6)
    y_a1 = ay2 - arrow_size * math.sin(angle - math.pi / 6)
    x_a2 = ax2 - arrow_size * math.cos(angle + math.pi / 6)
    y_a2 = ay2 - arrow_size * math.sin(angle + math.pi / 6)

    draw.line([ax2, ay2, int(x_a1), int(y_a1)], fill="red", width=line_width)
    draw.line([ax2, ay2, int(x_a2), int(y_a2)], fill="red", width=line_width)

    output_buffer = io.BytesIO()
    image.save(output_buffer, format="JPEG", quality=90)
    return output_buffer.getvalue()


def process_photo(folder_path, filename, arrow_data):
  raw_b64 = clean_base64(read_file_content(folder_path, filename))
  if not raw_b64:
    return False, f"Файл {filename} пуст"
  try:
    raw_bytes = base64.b64decode(raw_b64)
    if (
        arrow_data
        and arrow_data.get("arrow_start")
        and arrow_data.get("arrow_end")
    ):
      mod_bytes = draw_elements(
          raw_bytes,
          arrow_data["arrow_start"],
          arrow_data["arrow_end"],
          arrow_data.get("canvas_size") or {"w": 1, "h": 1},
      )
    else:
      with Image.open(io.BytesIO(raw_bytes)) as img:
        img = ImageOps.exif_transpose(img).convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=90)
        mod_bytes = buf.getvalue()
    write_file_content(
        folder_path, filename, base64.b64encode(mod_bytes).decode("utf-8")
    )
    return True, ""
  except Exception as e:
    return False, str(e)


def process_and_move_sync(
    folder_path, target_path, photo1_data, photo2_data, comment_text
):
  try:
    process_photo(folder_path, "1.txt", photo1_data)
    process_photo(folder_path, "2.txt", photo2_data)
    write_file_content(folder_path, "3.txt", encode_comment(comment_text))

    if os.path.exists(target_path):
      shutil.rmtree(target_path)
    shutil.move(folder_path, ZAGRUZKA_DIR)
    return True
  except Exception as e:
    print(f"Ошибка при обработке папки {folder_path}: {e}")
    return False


# ==========================================
# 3. МАРШРУТЫ И ЛОГИКА СЕРВЕРА
# ==========================================


@app.route("/")
def menu():
  return render_template("menu.html")


@app.route("/process")
def process():
  folders = get_target_folders(RAZMETKA_DIR)
  if not folders:
    return render_template("process.html", photo1=None, photo2=None, empty=True)

  if state["current_folder_idx"] >= len(folders):
    state["current_folder_idx"] = 0
    save_state()
  elif state["current_folder_idx"] < 0:
    state["current_folder_idx"] = len(folders) - 1
    save_state()

  current_folder = folders[state["current_folder_idx"]]
  folder_path = os.path.join(RAZMETKA_DIR, current_folder)

  photo1_b64 = clean_base64(read_file_content(folder_path, "1.txt"))
  photo2_b64 = clean_base64(read_file_content(folder_path, "2.txt"))

  full_text = decode_comment(read_file_content(folder_path, "3.txt"))
  comment_coords, comment_middle, comment_suffix = split_comment(full_text)

  return render_template(
      "process.html",
      empty=False,
      photo1=photo1_b64,
      photo2=photo2_b64,
      comment_coords=comment_coords,
      comment_middle=comment_middle,
      comment_suffix=comment_suffix,
      folder_name=current_folder,
      current_idx=state["current_folder_idx"],
      total_folders=len(folders),
  )


@app.route("/api/folder_count")
def get_folder_count():
  count_raz = (
      len(get_target_folders(RAZMETKA_DIR))
      if os.path.exists(RAZMETKA_DIR)
      else 0
  )
  count_zag = 0
  if os.path.exists(ZAGRUZKA_DIR):
    try:
      count_zag = len([
          n
          for n in os.listdir(ZAGRUZKA_DIR)
          if os.path.isdir(os.path.join(ZAGRUZKA_DIR, n))
      ])
    except Exception:
      pass
  return jsonify({"countRaz": count_raz, "countZag": count_zag})


@app.route("/save_gps", methods=["POST"])
def save_gps():
  data = request.json
  if data:
    try:
      now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
      with open(GPS_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(
            f"[{now}] Lat: {data.get('lat')}, Lon: {data.get('lon')}, Acc:"
            f" {data.get('acc')}m\n"
        )
    except Exception:
      pass
  return jsonify({"status": "ok"})


@app.route("/clear_dir", methods=["POST"])
def clear_dir():
  req_data = request.get_json(silent=True) or {}
  section = req_data.get("section")
  target_dir = RAZMETKA_DIR if section == "Разметка" else ZAGRUZKA_DIR
  if os.path.exists(target_dir):
    try:
      for item in os.listdir(target_dir):
        item_path = os.path.join(target_dir, item)
        if os.path.isdir(item_path):
          shutil.rmtree(item_path)
        else:
          os.remove(item_path)
    except Exception:
      pass

  if section == "Разметка":
    state["current_folder_idx"] = 0
  else:
    state["zagruzka_folder_idx"] = 0
  save_state()
  return jsonify({"status": "ok"})


@app.route("/delete_folder", methods=["POST"])
def delete_current_folder():
  folders = get_target_folders(RAZMETKA_DIR)
  if folders and state["current_folder_idx"] < len(folders):
    folder_path = os.path.join(
        RAZMETKA_DIR, folders[state["current_folder_idx"]]
    )
    if os.path.exists(folder_path):
      try:
        shutil.rmtree(folder_path)
      except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    folders = get_target_folders(RAZMETKA_DIR)
    if folders:
      state["current_folder_idx"] = min(
          state["current_folder_idx"], len(folders) - 1
      )
    else:
      state["current_folder_idx"] = 0
    save_state()
    return jsonify({"status": "ok"})
  return jsonify({"status": "error", "message": "Folder not found"}), 400


@app.route("/prev_folder", methods=["POST"])
def prev_folder():
  folders = get_target_folders(RAZMETKA_DIR)
  if folders:
    state["current_folder_idx"] = (state["current_folder_idx"] - 1) % len(
        folders
    )
    save_state()
  return jsonify({"status": "ok"})


@app.route("/skip_folder", methods=["POST"])
def skip_folder():
  folders = get_target_folders(RAZMETKA_DIR)
  if folders:
    state["current_folder_idx"] = (state["current_folder_idx"] + 1) % len(
        folders
    )
    save_state()
  return jsonify({"status": "ok"})


@app.route("/save_folder", methods=["POST"])
def save_folder():
  req_data = request.get_json(silent=True) or {}
  folders = get_target_folders(RAZMETKA_DIR)
  if not folders:
    return jsonify({"status": "error"}), 400

  if state["current_folder_idx"] >= len(folders):
    state["current_folder_idx"] = 0

  current_folder = folders[state["current_folder_idx"]]
  folder_path = os.path.join(RAZMETKA_DIR, current_folder)
  target_path = os.path.join(ZAGRUZKA_DIR, current_folder)

  coords = (req_data.get("coords") or "").strip()
  comment = (req_data.get("comment") or "").strip()
  
  suffix = COMMENT_SUFFIX.strip()
  if comment.endswith(suffix):
    comment = comment[:-len(suffix)].strip()

  parts = []
  if coords:
    parts.append(coords)
  if comment:
    parts.append(comment)
  parts.append(suffix)
  comment_text = "\n".join(parts)

  future = executor.submit(
      process_and_move_sync,
      folder_path,
      target_path,
      req_data.get("photo1_data"),
      req_data.get("photo2_data"),
      comment_text,
  )
  
  success = future.result()
  if not success:
    return jsonify({"status": "error"}), 500

  remaining_folders = get_target_folders(RAZMETKA_DIR)
  if remaining_folders:
    state["current_folder_idx"] = state["current_folder_idx"] % len(remaining_folders)
  else:
    state["current_folder_idx"] = 0
  save_state()

  return jsonify({"status": "ok"})


@app.route("/shutdown", methods=["POST"])
def shutdown():
  executor.shutdown(wait=False)
  os.kill(os.getpid(), signal.SIGINT)
  return jsonify({"success": True, "message": "Сервер останавливается..."})


@app.route("/zagruzka")
def zagruzka_view():
  folders = get_target_folders(ZAGRUZKA_DIR)
  if not folders:
    return render_template("zagruzka.html", empty=True)

  idx = state.get("zagruzka_folder_idx", 0)
  if idx >= len(folders):
    idx = 0
  elif idx < 0:
    idx = len(folders) - 1

  state["zagruzka_folder_idx"] = idx
  save_state()

  current_folder = folders[idx]
  folder_path = os.path.join(ZAGRUZKA_DIR, current_folder)

  photo1_b64 = clean_base64(read_file_content(folder_path, "1.txt"))
  photo2_b64 = clean_base64(read_file_content(folder_path, "2.txt"))
  full_text = decode_comment(read_file_content(folder_path, "3.txt"))

  return render_template(
      "zagruzka.html",
      empty=False,
      photo1=photo1_b64,
      photo2=photo2_b64,
      comment_text=full_text,
      folder_name=current_folder,
      current_idx=idx,
      total_folders=len(folders),
  )


@app.route("/api/zagruzka/action", methods=["POST"])
def zagruzka_action():
  req = request.json
  action = req.get("action")
  folders = get_target_folders(ZAGRUZKA_DIR)

  if not folders:
    return jsonify({"status": "error", "message": "Папок нет"})

  idx = state.get("zagruzka_folder_idx", 0)
  if idx >= len(folders):
    idx = 0

  current_folder = folders[idx]
  folder_path = os.path.join(ZAGRUZKA_DIR, current_folder)
  copy_text = ""

  if action == "next":
    state["zagruzka_folder_idx"] = (idx + 1) % len(folders)

  elif action == "prev":
    state["zagruzka_folder_idx"] = (idx - 1) % len(folders)

  elif action == "delete":
    shutil.rmtree(folder_path, ignore_errors=True)
    folders = get_target_folders(ZAGRUZKA_DIR)
    if folders:
      state["zagruzka_folder_idx"] = idx % len(folders)
    else:
      state["zagruzka_folder_idx"] = 0

  elif action == "select":
    copy_text = decode_comment(read_file_content(folder_path, "3.txt"))

    p1_b64 = clean_base64(read_file_content(folder_path, "1.txt"))
    p2_b64 = clean_base64(read_file_content(folder_path, "2.txt"))
    
    if p1_b64:
      try:
        with open(os.path.join(PHOTO_DEST_DIR, "1.jpg"), "wb") as f:
          f.write(base64.b64decode(p1_b64))
      except Exception:
        pass
        
    if p2_b64:
      try:
        with open(os.path.join(PHOTO_DEST_DIR, "2.jpg"), "wb") as f:
          f.write(base64.b64decode(p2_b64))
      except Exception:
        pass

    try:
      with open(os.path.join(PHOTO_DEST_DIR, "3.txt"), "w", encoding="utf-8") as f:
        f.write(copy_text)
    except Exception:
      pass

    zip_filename = f"{current_folder}.zip"
    temp_zip_path = os.path.join(ZAGRUZKA_DIR, zip_filename)
    with zipfile.ZipFile(temp_zip_path, "w", zipfile.ZIP_DEFLATED) as zip_file:
      for root, _, files in os.walk(folder_path):
        for file in files:
          full_path = os.path.join(root, file)
          arcname = os.path.relpath(full_path, folder_path)
          zip_file.write(full_path, arcname)

    final_zip_path = os.path.join(BACKUP_DIR, zip_filename)
    if os.path.exists(final_zip_path):
      os.remove(final_zip_path)
    shutil.move(temp_zip_path, final_zip_path)

    shutil.rmtree(folder_path, ignore_errors=True)

    folders = get_target_folders(ZAGRUZKA_DIR)
    if folders:
      state["zagruzka_folder_idx"] = idx % len(folders)
    else:
      state["zagruzka_folder_idx"] = 0

  save_state()
  return jsonify({"status": "ok", "copy_text": copy_text})


if __name__ == "__main__":
  app.run(host="0.0.0.0", port=5000, debug=False)
